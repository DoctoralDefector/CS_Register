import requests
import json

crn_uri = "https://registrationssb.drake.edu/StudentRegistrationSsb/ssb/searchResults/searchResults"

### GO HERE: https://registrationssb.drake.edu/StudentRegistrationSsb/ssb/registration
### THEN OPEN INSPECT ELEMENT, OBTAIN YOUR COOKIE FROM STORAGE
###
headers = {
    "Accept": "text/html",
    "Content-Type": "application/x-www-form-urlencoded",
    "Cookie": "JSESSIONID=F578AB2DCE4A41DBC093E0416C85F5BA",  ### PASTE YOUR COOKIE HERE ###
    "Host": "registrationssb.drake.edu",
}

# This function generates the json for CS classes
def gen_cs_json():
    # YOU NEED TO CHANGE THE SESSION ID TO A NEW ONE FROM YOUR SEARCH, IN INSPECT ELEMENT, IN THE NETWORK TAB
    uniq_id = "pcsif1670443753952"
    payload = (
        "txt_subject=CS&txt_term=202320&startDatepicker=&endDatepicker=&uniqueSessionId="
        + uniq_id
        + "&pageOffset=0&pageMaxSize=50&sortColumn=courseReferenceNumber&sortDirection=desc"
    )
    crn = requests.post(crn_uri, headers=headers, data=payload).text
    crn_load = json.loads(crn)
    with open("all_cs_courses.json", "w") as sd:
        json.dump(crn_load["data"], sd)


# This function generates the json for all classes
def gen_all_json():
    courses_data = []
    y = 500
    for x in range(0, 1500, 500):
        payload2 = f"txt_term=202320&startDatepicker=&endDatepicker=&uniqueSessionId=s8fax1670364483529&pageOffset={x}&pageMaxSize={y}&sortColumn=subjectDescription&sortDirection=asc"
        crn2 = requests.post(crn_uri, headers=headers, data=payload2).text
        crn_load2 = json.loads(crn2)
        crn_load2 = crn_load2["data"]
        courses_data += crn_load2
        y += 500

    with open("all_courses.json", "w") as sd:
        json.dump(courses_data, sd)


if __name__ == "__main__":
    gen_cs_json()
    gen_all_json()
