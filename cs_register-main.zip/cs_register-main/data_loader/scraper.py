import requests
import json
from bs4 import BeautifulSoup as bs

course_details_uri = "https://registrationssb.drake.edu/StudentRegistrationSsb/ssb/courseSearchResults/getCourseCatalogDetails"
prerequisites_uri = "https://registrationssb.drake.edu/StudentRegistrationSsb/ssb/courseSearchResults/getPrerequisites"
descriptions_uri = "https://registrationssb.drake.edu/StudentRegistrationSsb/ssb/courseSearchResults/getCourseDescription"
CORE_CLASSES = ["065", "066", "067", "083", "130", "137", "188", "191"]


def process_table(table):
    data = []
    if table:
        table_body = table.find("tbody")
        rows = table_body.find_all("tr")
        in_paranthese = False
        store_col = []
        col_as_string = ""
        for row in rows:

            cols = row.find_all("td")
            cols = [ele.text.strip() for ele in cols]
            if "(" in cols:  # data in () should stay as in same entry
                in_paranthese = True
            if ")" in cols:
                in_paranthese = False

            for str in cols:

                if len(str) > 1:
                    str += " "
                elif str == ")":
                    col_as_string = col_as_string.strip(
                        " "
                    )  # remove string in between course and closing parenthese
                col_as_string += str
            if not in_paranthese:  # Only append if not currently in between ()

                data.append(col_as_string.strip())  # just append string
                col_as_string = ""
    return data


def fetch_course_preq(filename):
    with open(filename) as sd:
        courses = json.load(sd)
    headers = {
        "Accept": "text/html",
        "Content-Type": "application/x-www-form-urlencoded",
        # Add your cookie here
        "Cookie": "JSESSIONID=8D2EA99ADEC94B1A3A7A42ED127A71A0",
        "Host": "registrationssb.drake.edu",
    }

    for c in courses:
        payload = f"term=202320&subjectCode={c['subject']}&courseNumber={c['courseNumber']}&first=first"
        pre_req = requests.post(prerequisites_uri, headers=headers, data=payload).text
        parsed_pre_req = bs(pre_req, "html.parser")
        table = parsed_pre_req.find("table", attrs={"class": "basePreqTable"})
        data = process_table(table)
        c["prerequisites"] = data
        c["division"] = (
            "core" if c["courseNumber"].casefold() in CORE_CLASSES else "upper"
        )

    with open(filename, "w") as sd:
        json.dump(courses, sd)


### function to get full course descriptions ###
def fetch_course_desc(filename):

    with open(filename) as sd:
        courses = json.load(sd)

    headers = {
        "Accept": "text/html, */*; q=0.01",
        "Content-Type": "application/x-www-form-urlencoded",
    }
    for c in courses:
        payload = {
            "subjectCode": c["subject"],
            "courseNumber": c["courseNumber"],
            "term": 202320,
        }

        desc = requests.post(descriptions_uri, headers=headers, data=payload).text

        c["courseDescription"] = add_course(desc)
    with open(filename, "w") as sd:
        json.dump(courses, sd)


def add_course(desc):

    parsed_desc = bs(desc, "html.parser")
    section = parsed_desc.find(
        "section", attrs={"aria-labelledby": "courseDescription"}
    )

    data = ""

    for i in section(["script", "span"]):
        i.decompose()

    full_desc = "".join(section.stripped_strings)
    data = full_desc
    return data


if __name__ == "__main__":
    fetch_course_desc("all_courses.json")
    fetch_course_preq("all_courses.json")
    # fetch_course_desc("all_cs_courses.json")
    # fetch_course_preq("all_cs_courses.json")
