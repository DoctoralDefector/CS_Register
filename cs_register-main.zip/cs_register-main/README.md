# CS_Register

## Getting started

This project uses a Model-View-Controller pattern. This is so the logic manipulating the visual components is seperated from the visual bits and the "models" or what we're showing on screen and their properties are separate from either of those things.

To get started I'd highly recommend adding a .vscode file that has something like the following:
```
{
    // Use IntelliSense to learn about possible attributes.
    // Hover to view descriptions of existing attributes.
    // For more information, visit: https://go.microsoft.com/fwlink/?linkid=830387
    "version": "0.2.0",
    "configurations": [
        {
            "name": "App Debug",
            "type": "python",
            "request": "launch",
            "program": "${workspaceFolder}/app.py",
            "console": "integratedTerminal"
        }
    ]
}
```
This will make it much easier to debug, print debugging will be even harder when gui programming.

You'll need to make sure that tk/tkinter is installed on your machine you can do this by something like:

```console
$ apt-get install python3-tk
```

I already had it installed on my system, but you may not. Odds are that if you're using an up to date version of python >3.7 then you'll be fine.
<br>
<br>

If you're using WSL you'll also need to take some steps to enable vGPU on WSL. Follow [these](https://learn.microsoft.com/en-us/windows/wsl/tutorials/gui-apps) instructions.
**Import to note you'll need to be running at least Windows 11 Build 22000 or later**

<br>

If you don't have Windows 11 installed, you'll have to test using your windows install of python. You'll probably have to install poetry etc. on the windows side as well.


Don't forget to do all of the normal poetry stuff too:

```console
$ poetry install
```

### Running from the command line
The usual works, but for a little convenience you can:
```console
$ poetry run cs_register
```


## Resources
This project uses the [tkinter](https://docs.python.org/3.8/library/tkinter.html#) as its gui framework there are lots of good tutorials.
Check out [this](https://www.pythontutorial.net/tkinter/tkinter-mvc/) one that I based the beginning of this project on.
