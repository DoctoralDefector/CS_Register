import os

from _pytest.fixtures import fixture

from app import App
from cs_register.src.views.degree_progress import degree_progress


@fixture
def sample_courses():
    return [
        "MATH 050",
        "Computer Organization and Assembly Language Programming",
        "CS 066",
        "IS 161",
    ]


@fixture
def start_tkinter():
    os.chdir("..")
    app = App()
    app.root.withdraw()
    degree_progress(app.notebook)
    return app
