import os

from cs_register.src.controllers.degree_progress_controller import (
    degree_progress_control,
)


def test_degree_progress_progressbar_len():
    test_return = degree_progress_control().degree_progress_progressbar_len(core=True)
    assert type(test_return) is int
    dpc_test = degree_progress_control()
    dpc_test.core_classes = []
    try:
        dpc_test.degree_progress_progressbar_len()
    except ZeroDivisionError:
        assert True
    else:
        assert False


def test_missing_classes_display():
    test_dpc = degree_progress_control()
    func_return = test_dpc.missing_classes_display()
    assert type(func_return) is tuple, tuple
    assert func_return or test_dpc.current_transcript


def test_find_core_upper():
    test_dpc = degree_progress_control()
    test_dpc.find_core_upper()
    assert len(test_dpc.core_classes) == len(set(test_dpc.core_classes))
    assert len(test_dpc.upper_division_classes) == len(
        set(test_dpc.upper_division_classes)
    )
    if len(test_dpc.upper_division_classes) > 1:
        assert test_dpc.upper_division_classes[0].split(" ")[0] != " "


def test_find_course_by_id():
    test_dpc = degree_progress_control()
    assert (
        test_dpc.find_course_by_id("CS 67")["courseTitle"]
        == "OBJECT-ORIENTED PROGRAMMING"
    )
    assert type(test_dpc.find_course_by_id("CS 67")) is dict
    assert test_dpc.find_course_by_id("CS 100000") != -1
    assert (
        test_dpc.find_course_by_id("CS 067")["courseTitle"]
        == "OBJECT-ORIENTED PROGRAMMING"
    )
