import os
import tkinter
from unittest import mock

from _pytest.fixtures import fixture

from app import App
from cs_register.src.views.degree_progress import degree_progress

"""
Note:
These tests all require a display to work as they test the degree progres view, therefore they do not 
work with the pipline, that's why they are commented out. -CB

@fixture
def start_tkinter():
    if os.environ.get("DISPLAY", "") == "":
        os.environ.__setitem__("DISPLAY", ":0")
    os.chdir("..")
    app = App()
    app.root.withdraw()
    degree_progress(app.notebook)
    return app


def test_insert_items(start_tkinter):
    test_listbox = tkinter.Listbox(start_tkinter.root)
    degree_progress(start_tkinter.notebook).insert_items(test_listbox, ["CS 200"])
    items = test_listbox.get(0, tkinter.END)
    assert items[0] == "CS 200"


@mock.patch("cs_register.src.views.degree_progress.degree_progress.callback_body")
def test_callback_add(callback_body_mock, start_tkinter):
    test_virtual_event = tkinter.Event
    start_tkinter.degree_progress.callback_add(test_virtual_event)
    assert callback_body_mock.call_count == 1


@mock.patch("cs_register.src.views.degree_progress.degree_progress.callback_body")
def test_callback_remove(callback_body_mock, start_tkinter):
    test_virtual_event = tkinter.Event
    start_tkinter.degree_progress.callback_add(test_virtual_event)
    assert callback_body_mock.call_count == 1


def test_callback_body(start_tkinter):
    test_listbox = tkinter.Listbox(start_tkinter.root)
    test_virtual_event = tkinter.Event
    test_virtual_event.widget = test_listbox
    start_tkinter.degree_progress.callback_body(test_virtual_event, True)
    assert start_tkinter.degree_progress.grid_taken is not None


def test_on_selection(start_tkinter):
    test_stringVar = tkinter.StringVar()
    test_stringVar.set("Core Classes")
    start_tkinter.degree_progress.clicked = test_stringVar
    start_tkinter.degree_progress.on_selection()
    assert start_tkinter.degree_progress.pb_label is not None
    assert start_tkinter.degree_progress.degree_progress["value"] > -1


def test_create_progressbar(start_tkinter):
    start_tkinter.degree_progress.create_progressbar()
    assert start_tkinter.degree_progress.clicked.get() is ""


def test_add_to_transcript_on_click(start_tkinter):
    start_tkinter.degree_progress.add_to_transcript_on_click("CS 212")
    assert "CS 212" in start_tkinter.degree_progress.taken_cour_list
    list_box_taken_obj = start_tkinter.degree_progress.courses_taken_list_box.get(
        0, tkinter.END
    )
    assert "CS 212" in list_box_taken_obj
    list_box_core_obj = start_tkinter.degree_progress.courses_needed_list_box.get(
        0, tkinter.END
    )
    assert "CS 212" not in list_box_core_obj
    list_box_upper_obj = start_tkinter.degree_progress.upper_level_list_box.get(
        0, tkinter.END
    )
    assert "CS 212" not in list_box_upper_obj
    start_tkinter.degree_progress.remove_from_transcript_on_click("CS 212")


def test_remove_from_transcript_on_click(start_tkinter):
    start_tkinter.degree_progress.add_to_transcript_on_click("CS 312")
    start_tkinter.degree_progress.remove_from_transcript_on_click("CS 312")
    assert "CS 312" not in start_tkinter.degree_progress.taken_cour_list
    list_box_taken_obj = start_tkinter.degree_progress.courses_taken_list_box.get(
        0, tkinter.END
    )
    assert "CS 312" not in list_box_taken_obj


def test_update_transcript_classes(start_tkinter):
    start_tkinter.degree_progress.update_transcript_classes()
    assert start_tkinter.degree_progress.needed_cour_list is not []
    assert start_tkinter.degree_progress.uppper_cour_list is not []
"""
