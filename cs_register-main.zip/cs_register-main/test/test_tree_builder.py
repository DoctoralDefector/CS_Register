import cs_register.src.utils.tree_builder as tb
from unittest import mock
from pytest import fixture


@fixture
def sample_courses():
    return ["CS 065", "CS 066", "CS 067", "CS 083", "CS 130"]


@fixture
def sample_prereqs():
    return {
        "CS 065": [],
        "CS 066": ["CS 065"],
        "CS 067": ["CS 066"],
        "CS 083": [],
        "CS 130": ["CS 066"],
    }


@fixture
def sample_completes():
    return [[], ["CS 065"], ["CS 065", "CS 066", "CS 067", "CS 083", "CS 130"]]


def test_tree_builder_no_complete(sample_courses, sample_prereqs, sample_completes):
    completed = sample_completes[0]
    testTree = tb.create_tree(sample_courses, sample_prereqs, completed)[0]
    resEdges = testTree.get_edgelist()
    expectedEdges = [(0, 1), (1, 2), (1, 4)]
    assert resEdges == expectedEdges
    assert testTree.vs["completed"] == [False, False, False, False, False]


def test_tree_builder_some_complete(sample_courses, sample_prereqs, sample_completes):
    completed = sample_completes[1]
    testTree = tb.create_tree(sample_courses, sample_prereqs, completed)[0]
    resEdges = testTree.get_edgelist()
    expectedEdges = [(0, 1), (1, 2), (1, 4)]
    assert resEdges == expectedEdges
    assert testTree.vs["completed"] == [True, False, False, False, False]


def test_tree_builder_all_complete(sample_courses, sample_prereqs, sample_completes):
    completed = sample_completes[2]
    testTree = tb.create_tree(sample_courses, sample_prereqs, completed)[0]
    resEdges = testTree.get_edgelist()
    expectedEdges = [(0, 1), (1, 2), (1, 4)]
    assert resEdges == expectedEdges
    assert testTree.vs["completed"] == [True, True, True, True, True]


def test_tree_to_ImageTk():
    pass
