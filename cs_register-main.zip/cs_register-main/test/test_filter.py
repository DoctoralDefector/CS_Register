import cs_register.src.controllers.course_box_controller as cbc
import cs_register.src.models.courses as courseModel
from pytest import fixture
from unittest import mock

"""
Going to attempt to test this with mocks
I want to test to see if the length of the filtered list, matches the length shown on GUI
Need to mock start and end time?
"""


@fixture
def sample_course_list():
    return [
        courseModel.Course("testing", "", "CS", "066", "0600", "0700"),
        courseModel.Course("testing", "", "CS", "067", "0800", "0900"),
    ]


@mock.patch(
    "cs_register.src.controllers.course_box_controller.CourseBoxController.load_courses"
)
def test_filter_courses(load_courses_patch, sample_course_list):
    test_controller = cbc.CourseBoxController(None, None)
    assert len(test_controller.filter_courses("0600", "0600", sample_course_list)) == 1
