import json
import os

from cs_register.src.utils.utils import transcript_worker


def test_dump_transcript():
    tw = transcript_worker()
    tw.current_tran = "bonjour"
    tw.dump_transcript()
    with open("transcript_store.json") as ts:
        file_data = json.load(ts)
    os.remove("transcript_store.json")
    assert "".join(list(file_data)) == "bonjour"


def test_set_transcript(sample_courses):
    tw = transcript_worker()
    tw.set_transcript(sample_courses)
    assert tw.current_tran == set(sample_courses)


def test_load_transcript(sample_courses):
    tw = transcript_worker()
    json_test_dump = json.dumps(sample_courses)
    with open("transcript_store.json", "w") as ts:
        ts.write(json_test_dump)
    tw.load_transcript()
    assert tw.current_tran == set(sample_courses)


def test_get_current_tran(sample_courses):
    tw = transcript_worker()
    json_test_dump = json.dumps(sample_courses)
    with open("transcript_store.json", "w") as ts:
        ts.write(json_test_dump)
    assert tw.get_current_tran() == set(sample_courses)
