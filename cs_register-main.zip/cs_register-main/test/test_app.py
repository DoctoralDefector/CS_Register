def test_app():
    pass


# Had to comment this out, since async is not working properly with pipeline. Tests pass, but multithreading causes warning that makes it fail on pipeline but succeed on local machine.
"""
from pytest import fixture
import unittest
from unittest.mock import patch
from app import App
from app import run


# Test warning is to be expected since we are not being sticklers for multithreading in this context


class TestGui(unittest.TestCase):
    async def _start_app(self):
        self.app.root.mainloop()

    def setUp(self):
        self.app = run()
        self._start_app()

    def tearDown(self):
        self.app.root.quit()

    def test_startup(self):
        title = self.app.root.title()
        expected = "CS_Register"
        self.assertEqual(title, expected)




"""
