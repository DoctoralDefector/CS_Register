from data_loader.scraper import process_table
from unittest.mock import patch
from pytest import fixture
from bs4 import BeautifulSoup as bs
from data_loader.scraper import add_course


@fixture
def fake_table():  # table taken from CS capstone
    table = """ <table class="basePreqTable">
                <thead>
                <tr>
                    <th>And/Or</th>
                    <th></th>
                    <th>Test</th>
                    <th>Score</th>
                    <th>Subject</th>
                    <th>Course Number</th>
                    <th>Level</th>
                    <th>Grade</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                
                    <tr>
                        
                            <td></td>
                        
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>Computer Sciences</td>
                        <td>066</td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                
                    <tr>
                        
                            <td>And</td>
                        
                        <td>(</td>
                        <td></td>
                        <td></td>
                        <td>Statistics</td>
                        <td>130</td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                
                    <tr>
                        
                            <td>Or</td>
                        
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>Mathematics</td>
                        <td>130</td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                
                    <tr>
                        
                            <td>Or</td>
                        
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>Actuarial Science</td>
                        <td>131</td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                
                    <tr>
                        
                            <td>Or</td>
                        
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>Mathematics</td>
                        <td>131</td>
                        <td></td>
                        <td></td>
                        <td>)</td>
                    </tr>
                
                    <tr>
                        
                            <td>And</td>
                        
                        <td>(</td>
                        <td></td>
                        <td></td>
                        <td>Statistics</td>
                        <td>170</td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                
                    <tr>
                        
                            <td>And</td>
                        
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>Statistics</td>
                        <td>172</td>
                        <td></td>
                        <td></td>
                        <td>)</td>
                    </tr>
                
                    <tr>
                        
                            <td>Or</td>
                        
                        <td>(</td>
                        <td></td>
                        <td></td>
                        <td>Statistics</td>
                        <td>170</td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                
                    <tr>
                        
                            <td>And</td>
                        
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>Computer Sciences</td>
                        <td>167</td>
                        <td></td>
                        <td></td>
                        <td>)</td>
                    </tr>
                
                    <tr>
                        
                            <td>Or</td>
                        
                        <td>(</td>
                        <td></td>
                        <td></td>
                        <td>Statistics</td>
                        <td>170</td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                
                    <tr>
                        
                            <td>And</td>
                        
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>Computer Sciences</td>
                        <td>178</td>
                        <td></td>
                        <td></td>
                        <td>)</td>
                    </tr>
                
                    <tr>
                        
                            <td>Or</td>
                        
                        <td>(</td>
                        <td></td>
                        <td></td>
                        <td>Statistics</td>
                        <td>172</td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                
                    <tr>
                        
                            <td>And</td>
                        
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>Computer Sciences</td>
                        <td>167</td>
                        <td></td>
                        <td></td>
                        <td>)</td>
                    </tr>
                
                    <tr>
                        
                            <td>Or</td>
                        
                        <td>(</td>
                        <td></td>
                        <td></td>
                        <td>Statistics</td>
                        <td>172</td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                
                    <tr>
                        
                            <td>And</td>
                        
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>Computer Sciences</td>
                        <td>178</td>
                        <td></td>
                        <td></td>
                        <td>)</td>
                    </tr>
                
                    <tr>
                        
                            <td>Or</td>
                        
                        <td>(</td>
                        <td></td>
                        <td></td>
                        <td>Computer Sciences</td>
                        <td>167</td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                
                    <tr>
                        
                            <td>And</td>
                        
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>Computer Sciences</td>
                        <td>178</td>
                        <td></td>
                        <td></td>
                        <td>)</td>
                    </tr>
                
                </tbody>
            </table>
            """
    parser = bs(table, "html.parser")
    data = parser.find("table", attrs={"class": "basePreqTable"})
    return data


@fixture
def answer_key():
    return [
        "Computer Sciences 066",
        "And (Statistics 130 Or Mathematics 130 Or Actuarial Science 131 Or Mathematics 131)",
        "And (Statistics 170 And Statistics 172)",
        "Or (Statistics 170 And Computer Sciences 167)",
        "Or (Statistics 170 And Computer Sciences 178)",
        "Or (Statistics 172 And Computer Sciences 167)",
        "Or (Statistics 172 And Computer Sciences 178)",
        "Or (Computer Sciences 167 And Computer Sciences 178)",
    ]


def test_process_prereq(fake_table, answer_key):
    assert process_table(fake_table) == answer_key


@fixture
def example_desc_html():
    return '\n<section aria-labelledby="courseDescription">\n    Algorithms, programming, program structures and computing systems. Debugging and verification of programs, data presentation. Computer solution of problems using a high- level language. Prereq.: Four years of high school mathematics or MATH 20.\n    \n</section>\n'


@fixture
def example_desc():
    return "Algorithms, programming, program structures and computing systems. Debugging and verification of programs, data presentation. Computer solution of problems using a high- level language. Prereq.: Four years of high school mathematics or MATH 20."


def test_desc(example_desc_html, example_desc):

    assert add_course(example_desc_html) == example_desc
