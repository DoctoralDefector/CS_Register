# tkinter import * is conventional practice
import tkinter as tk
import os
from tkinter import ttk

from cs_register.src.controllers.course_box_controller import CourseBoxController
from cs_register.src.models.courses import Courses
from cs_register.src.views.course_box import CourseBox
from cs_register.src.views.degree_progress import degree_progress
import cs_register.src.utils.tree_builder as tb


class App:
    def __init__(self):
        self.root = tk.Tk()
        self.root.geometry("680x600")
        self.root.title("CS_Register")

        self.main_frame = tk.Frame(self.root)
        self.main_frame.grid(row=0, column=0, sticky="nswe")

        # Create notebook
        self.notebook = ttk.Notebook(self.main_frame)
        self.notebook.pack(pady=10)

        # Create test_tab #1
        self.course_box = CourseBox(self.notebook)
        self.course_box.grid(row=1, column=0, sticky="nswe")
        self.course_model = Courses()
        self.course_box_controller = CourseBoxController(
            self.course_model, self.course_box
        )
        self.course_box.set_controller(self.course_box_controller)
        self.course_box.pack(fill="both")
        self.notebook.add(self.course_box, text="CourseBox")

        # Create Degree Progres tab
        self.degree_progress = degree_progress(self.notebook)
        self.degree_progress.grid(row=1)
        self.degree_progress.pack(pady=30)
        self.degree_progress.pack(fill="both")
        self.notebook.add(self.degree_progress, text="Degree Progress")

        # Create skill tree tab
        self.skill_tree_tab = tk.Frame(self.notebook, width=580, height=480)
        self.skill_tree_tab.pack(fill="both")

        # Courses Required to graduate based on checklist at https://www.drake.edu/media/departmentsoffices/computerscience/documents/Major%20checklist%20-%20CS.xlsx
        # and the prerequisites required for the courses on the checklist
        required_courses = [
            "MATH 020",
            "MATH 054",
            "CS 137",
            "MATH 100",
            "CS 130",
            "MATH 080",
            "MATH 101",
            "CS 083",
            "CS 188",
            "MATH 050",
            "CS 191",
            "CS 067",
            "CS 065",
            "MATH 070",
            "CS 066",
        ]

        # Prerequisites for the required courses, these are hardcoded as parsing the all_courses.json for prerequisites is still a WIP
        prereqs = {
            "CS 065": [],
            "CS 066": ["CS 065"],
            "CS 067": ["CS 066"],
            "CS 083": [],
            "CS 130": ["CS 066"],
            "CS 137": ["CS 067", "MATH 050", ["MATH 054", "MATH 101"]],
            "CS 188": ["CS 067"],
            "CS 191": ["CS 188"],
            "MATH 020": [],
            "MATH 050": ["MATH 020"],
            "MATH 054": [["MATH 020", "MATH 050", "MATH 070"]],
            "MATH 070": ["MATH 050"],
            "MATH 080": ["MATH 050"],
            "MATH 100": ["MATH 070"],
            "MATH 101": ["MATH 070", "MATH 080", "MATH 100"],
        }

        # Creating skill tree and an image of the skill tree
        skill_tree = tb.create_tree(required_courses, prereqs)
        skill_tree_img = tb.tree_to_ImageTk(skill_tree)

        # Placing the skill_tree_image on skill_tree_label
        self.skill_tree_label = tk.Label(self.skill_tree_tab, image=skill_tree_img)
        self.skill_tree_label.image = skill_tree_img
        self.skill_tree_label.pack()

        # Place skill_tree_label on the skill tree tab
        self.notebook.add(self.skill_tree_tab, text="Skill Tree")

        # add menubar
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="Help", command=lambda: os.system("help.txt"))
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        menubar.add_cascade(label="File", menu=file_menu)

    def mainloop(self):
        self.root.mainloop()


# define two entry points for easy cmd use
def run():
    app = App()
    app.mainloop()


if __name__ == "__main__":
    run()
