from tkinter import ttk
import tkinter as tk


# from tkinter import *


class CourseBox(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.courses = []
        self.before_time = "0600"
        self.after_time = "1900"
        self.courses_list_box = tk.Listbox(self)
        self.courses_list_box.grid(row=2, column=1, sticky=tk.S, padx=10, pady=10)

        self.SCALE_LABELS = {}
        sl_counter = 0
        for i in range(6, 19):
            for x in range(0, 60, 15):
                if i < 10:
                    if x == 0:
                        self.SCALE_LABELS[sl_counter] = "0" + str(i) + "00"
                    else:
                        self.SCALE_LABELS[sl_counter] = "0" + str(i) + str(x)

                else:
                    if x == 0:
                        self.SCALE_LABELS[sl_counter] = str(i) + "00"
                    else:
                        self.SCALE_LABELS[sl_counter] = str(i) + str(x)

                sl_counter += 1
        self.SCALE_LABELS[sl_counter] = "1900"

        self.message_label = ttk.Label(self, text="", foreground="red")
        self.message_label.grid(row=2, column=1, sticky=tk.W)
        self.controller = None

        self.filter_courses_before = tk.Scale(  # removes courses before the time set
            self,
            from_=min(self.SCALE_LABELS),
            to=max(self.SCALE_LABELS),
            label="Filter Before This Time: 0600",
            showvalue=False,
            command=self.scale_before_labels,
            orient=tk.HORIZONTAL,
            length=200,
        )
        self.filter_courses_before.set(0)
        self.filter_courses_before.grid(row=4, column=1, sticky=tk.W)

        self.filter_courses_after = tk.Scale(  # removes courses before the time set
            self,
            from_=min(self.SCALE_LABELS),
            to=max(self.SCALE_LABELS),
            label="Filter After This Time",
            showvalue=False,
            command=self.scale_after_labels,
            orient=tk.HORIZONTAL,
            length=200,
        )
        self.filter_courses_after.set(57)
        self.filter_courses_after.grid(row=12, column=1, sticky=tk.W)

        self.reset_filter_button = ttk.Button(
            self, text="Reset Filters", command=self.reset_filter_button_clicked
        )
        self.reset_filter_button.grid(row=20, column=1, padx=10)

    def set_controller(self, controller):
        self.controller = controller

    def show_courses(self, courses):
        self.courses_list_box.delete(0, self.courses_list_box.size())
        for idx, c in enumerate(courses):
            display_string = f"{c.subject} {c.course_id}: {c.name}"
            self.courses_list_box.insert(idx, display_string)

    def show_success(self, message):
        """
        Show a success message
        :param message:
        :return:
        """
        self.message_label["text"] = message
        self.message_label["foreground"] = "green"
        self.message_label.after(3000, self.hide_message)

    def hide_message(self):
        """
        Hide the message
        :return:
        """
        self.message_label["text"] = ""

    def reset_filter_button_clicked(self):
        self.filter_courses_before.set(0)
        self.filter_courses_after.set(56)
        self.before_time = "0800"
        self.after_time = "1845"
        self.courses = self.controller.load_courses()

    def scale_before_labels(  # changes the label on slider, chances the before_time to scaler, scaler load_courses() automatically
        self, value
    ):
        self.filter_courses_before.config(
            label="Filter Before This Time: " + self.SCALE_LABELS[int(value)]
        )
        self.before_time = self.SCALE_LABELS[int(value)]

        if self.controller:
            self.courses = self.controller.load_courses()

    def scale_after_labels(  # changes the label on slider, chances the after_time to scaler, scaler load_courses() automatically
        self, value
    ):
        self.filter_courses_after.config(
            label="Filter After This Time: " + self.SCALE_LABELS[int(value)]
        )
        self.after_time = self.SCALE_LABELS[int(value)]

        if self.controller:
            self.courses = self.controller.load_courses()
