import tkinter as tk
from tkinter import ttk

from cs_register.src.controllers.degree_progress_controller import (
    degree_progress_control,
)
from cs_register.src.utils import utils


class degree_progress(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)

        self.classes_taken = []
        self.grid_taken = []
        self.dp = degree_progress_control()
        self.tw = utils.transcript_worker()
        self.uppper_cour_list = []
        self.needed_cour_list = []
        self.taken_cour_list = []
        self.update_transcript_classes()
        self.degree_progress = ttk.Progressbar(self, length=200, mode="determinate")
        self.create_progressbar()
        tk.Label(self, text="Taken Courses").grid(row=2, column=3, sticky=tk.S, padx=10)
        self.courses_taken_list_box = tk.Listbox(self)
        self.courses_taken_list_box.grid(row=3, column=3, sticky=tk.S, padx=10, pady=10)
        self.insert_items(
            list_box=self.courses_taken_list_box, insert_list=self.taken_cour_list
        )
        self.courses_taken_list_box.bind("<<ListboxSelect>>", self.callback_remove)
        # Needed Courses listbox and label
        tk.Label(self, text="Needed Core Courses").grid(
            row=2, column=2, sticky=tk.S, padx=10
        )
        self.courses_needed_list_box = tk.Listbox(self)
        self.courses_needed_list_box.grid(
            row=3, column=2, sticky=tk.S, padx=10, pady=10
        )
        self.insert_items(
            list_box=self.courses_needed_list_box, insert_list=self.needed_cour_list
        )
        self.courses_needed_list_box.bind("<<ListboxSelect>>", self.callback_add)

        # Suggested Courses Listbox and label
        tk.Label(self, text="Needed Upper-level Courses").grid(
            row=4, column=2, sticky=tk.S, padx=10
        )
        self.upper_level_list_box = tk.Listbox(self)
        self.upper_level_list_box.grid(row=5, column=2, sticky=tk.S, padx=10, pady=10)
        self.insert_items(
            list_box=self.upper_level_list_box,
            insert_list=self.uppper_cour_list,
        )
        self.upper_level_list_box.bind("<<ListboxSelect>>", self.callback_add)

    def insert_items(self, list_box: tk.Listbox, insert_list: list[str]):
        for val, item in enumerate(insert_list):
            list_box.insert(val, item)

    def callback_add(self, event):
        self.callback_body(event, False)

    def callback_remove(self, event):
        self.callback_body(event, True)

    def callback_body(self, event, remove_from_ts):
        if len(self.grid_taken) > 1:
            for obj in self.grid_taken:
                obj.grid_forget()
        eventWidget = event.widget
        self.selection = eventWidget.curselection()
        if self.selection:
            data = event.widget.get(self.selection[0])
            if remove_from_ts:
                lamda_on_click = lambda: self.remove_from_transcript_on_click(data)
                button_text = f"Remove {data} from transcript"
            else:
                lamda_on_click = lambda: self.add_to_transcript_on_click(data)
                button_text = f"Add {data} to transcript"

            self.trans_add_button = tk.Button(
                self, text=button_text, command=lamda_on_click, wraplength=90
            )
            self.trans_add_button.grid(row=5, column=3, sticky=tk.S, padx=10, pady=10)
            selected_course = self.dp.find_course_by_id(data)
            if selected_course != -1:
                selected_name = selected_course["courseTitle"]
                self.selected_title_label = tk.Label(
                    self, text=f"Selected:\n {selected_name}", wraplength=101
                )
                self.selected_title_label.grid(
                    row=5, column=3, sticky=tk.N, padx=10, pady=10
                )
                self.grid_taken.append(self.selected_title_label)
            self.grid_taken.append(self.trans_add_button)

    def on_selection(self):
        selection = self.clicked.get()
        textMessage = "Progress to completion of " + selection.lower()
        self.pb_label.config(text=textMessage)
        if selection == "Core Classes":
            self.degree_progress["value"] = self.dp.degree_progress_progressbar_len(
                core=True
            )
        else:
            self.degree_progress["value"] = self.dp.degree_progress_progressbar_len(
                core=False
            )

    def create_progressbar(self):
        self.degree_progress.grid(row=3, column=1, sticky=tk.N, padx=10, pady=10)
        self.clicked = tk.StringVar()
        degree_progres_drop = tk.OptionMenu(
            self,
            self.clicked,
            *["Core Classes", "Upper-Level Classes"],
            command=lambda x: self.on_selection(),
        )
        degree_progres_drop.grid(row=2, column=1, sticky=tk.S, padx=10, pady=10)
        self.pb_label = tk.Label(
            self, text="Select completion qualifier\n   ", wraplength=150
        )
        self.pb_label.grid(row=1, column=1, sticky=tk.S, padx=10, pady=10)

    def add_to_transcript_on_click(self, item):
        self.tw.set_transcript(item)
        self.taken_cour_list.append(item)
        if item in self.uppper_cour_list:
            self.uppper_cour_list.remove(item)
            idx = self.upper_level_list_box.get(0, tk.END).index(item)
            self.upper_level_list_box.delete(idx)
        elif item in self.needed_cour_list:
            self.needed_cour_list.remove(item)
            idx = self.courses_needed_list_box.get(0, tk.END).index(item)
            self.courses_needed_list_box.delete(idx)
        self.courses_taken_list_box.delete(0, tk.END)
        self.insert_items(
            list_box=self.courses_taken_list_box, insert_list=self.taken_cour_list
        )

    def remove_from_transcript_on_click(self, item):
        self.tw.remove_from_transcript(item)
        self.update_transcript_classes()
        idx = self.courses_taken_list_box.get(0, tk.END).index(item)
        self.courses_taken_list_box.delete(idx)
        self.courses_needed_list_box.delete(0, tk.END)
        self.insert_items(
            list_box=self.courses_needed_list_box, insert_list=self.needed_cour_list
        )
        self.upper_level_list_box.delete(0, tk.END)
        self.insert_items(
            list_box=self.upper_level_list_box, insert_list=self.uppper_cour_list
        )

    def update_transcript_classes(self):
        missing_cour = self.dp.missing_classes_display()
        self.needed_cour_list = missing_cour[0]
        self.uppper_cour_list = missing_cour[1]
        self.taken_cour_list = self.dp.current_transcript
