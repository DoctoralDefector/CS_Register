from typing import Iterable
from typing import List


class Course:
    def __init__(self, name, description, subject, course_id, start_time, end_time):
        self.name = name
        self.descripton = description
        self.subject = subject
        self.course_id = course_id
        self.start_time = start_time if start_time else "0000"
        self.end_time = end_time if end_time else "0000"

    @classmethod
    def load(cls, db_model: dict):
        return Course(
            name=db_model.get("courseTitle"),
            description=db_model.get("courseDescription"),
            subject=db_model.get("subject"),
            course_id=db_model.get("courseNumber"),
            start_time=db_model.get("meetingsFaculty")[0]
            .get("meetingTime")
            .get("beginTime"),
            end_time=db_model.get("meetingsFaculty")[0]
            .get("meetingTime")
            .get("endTime"),
        )


class Courses:
    def __init__(self):
        self.courses = []

    def load(self, courses: List) -> List[Course]:
        self.courses = [Course.load(course) for course in courses]

    def get_courses(self):
        return self.courses

    def find_course_by_name(self, f_name):
        for c in self.courses:
            if c.name == f_name:
                return c
        return -1

    def find_course_by_id(self, f_id):
        f_id = f_id.split(" ")[1]
        for c in self.courses:
            if c.course_id.strip("0") == f_id:
                return c
        return -1
