from math import ceil
from typing import Any

from cs_register.src.utils.db import load_courses
from cs_register.src.utils.utils import transcript_worker


class degree_progress_control:
    def __init__(self):
        self.current_transcript = None
        self.all_classes = load_courses()
        self.upper_division_classes = []
        self.core_classes = []
        self.find_core_upper()
        self.tw = transcript_worker()

    def degree_progress_progressbar_len(self, core=True) -> int:
        self._dp_get_current_trans()
        if core:
            cmpLst = self.core_classes
        else:
            cmpLst = self.upper_division_classes
        compare_num = 0
        for x in cmpLst:
            if x in self.current_transcript:
                compare_num += 1
        return ceil(compare_num / len(cmpLst) * 100)

    def missing_classes_display(self) -> tuple[list[Any], list[Any]]:
        self._dp_get_current_trans()
        return list(set(self.core_classes).difference(self.current_transcript)), list(
            set(self.upper_division_classes).difference(self.current_transcript)
        )

    def find_core_upper(self):
        for course in self.all_classes:
            if course["division"] == "upper":
                course = course["subject"] + " " + course["courseNumber"].strip("0")
                self.upper_division_classes.append(course)
                self.upper_division_classes = [*set(self.upper_division_classes)]
            elif course["division"] == "core":
                course = course["subject"] + " " + course["courseNumber"].strip("0")
                self.core_classes.append(course)
                self.core_classes = [*set(self.core_classes)]

    def _dp_get_current_trans(self):
        ct = self.tw.get_current_tran()
        new_ct = []
        for cls in ct:
            c = cls.split(" ")
            new_ct.append(c[0] + " " + c[1].strip("0"))
        self.current_transcript = new_ct

    def find_course_by_id(self, f_id):
        f_id = f_id.split(" ")[1].strip("0")
        for c in self.all_classes:
            if c["courseNumber"].strip("0") == f_id:
                return c
        return -1
