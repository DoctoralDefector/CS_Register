from cs_register.src.utils import db
from cs_register.src.models.courses import Courses


class CourseBoxController:
    def __init__(self, courses_model: Courses, course_box_view):

        self.courses_model = courses_model
        self.course_box_view = course_box_view
        self.load_courses()

    def filter_courses(self, before_time, after_time, source_list=None):
        if not source_list:
            source_list = self.courses_model.get_courses()
        filtered_courses = [
            course
            for course in source_list
            if int(after_time) >= int(course.start_time) >= int(before_time)
        ]
        return filtered_courses

    def load_courses(self) -> Courses:
        courses = db.load_courses()
        # Retrieves before_time and after_time from course_box_view
        before_time = self.course_box_view.before_time
        after_time = self.course_box_view.after_time
        self.courses_model.load(courses)
        filtered_courses = self.filter_courses(before_time, after_time)
        self.course_box_view.show_courses(filtered_courses)
