import json
import os


class transcript_worker:
    def __init__(self):
        self.current_tran = set()
        if not os.path.isfile("transcript_store.json"):
            self.dump_transcript()
        self.load_transcript()

    def dump_transcript(self):
        json_obj = json.dumps(list(self.current_tran))
        with open("transcript_store.json", "w") as ts:
            ts.write(json_obj)

    def set_transcript(self, trans):
        if type(trans) == list:
            for cls in trans:
                self.current_tran.add(cls)
                self.dump_transcript()
        else:
            self.current_tran.add(trans)
            self.dump_transcript()

    def remove_from_transcript(self, item):
        if item in self.current_tran:
            self.current_tran.remove(item)
            self.dump_transcript()

    def clear_transcript(self):
        self.current_tran = set()
        self.dump_transcript()

    def load_transcript(self):
        with open("transcript_store.json", "r") as ts:
            json_ts = json.load(ts)
        self.current_tran = set(json_ts)

    def get_current_tran(self) -> set:
        self.load_transcript()
        return self.current_tran
