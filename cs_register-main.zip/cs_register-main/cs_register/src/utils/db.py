### Interface with database
import sqlite3 as sl
import json

DEFAULT_CONN_STR = "courses.db"

db_conn = None


def get_db_connection(conn_str=None):
    global db_conn
    if db_conn:
        return db_conn
    elif conn_str:
        db_conn = sl.connect(conn_str)
        return db_conn


def load_courses():
    # fake it for now
    all_courses = json.load(open("all_courses.json"))
    return all_courses
    # with get_db_connection() as conn:
    #     return conn.execute(
    #         """
    #         select name, id, description
    #         from courses
    #     """
    #     )
