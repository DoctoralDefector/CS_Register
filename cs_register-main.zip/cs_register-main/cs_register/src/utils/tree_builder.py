import igraph as ig
import matplotlib.pyplot as plt
from typing import List, Tuple
from PIL import Image, ImageTk
import os


def create_tree(
    courses: List, course_prereqs: dict[List], completed_courses=[]
) -> Tuple[ig.Graph, List[str]]:
    edges = []
    edge_color = []

    for course in courses:
        for prereq in course_prereqs[course]:
            if type(prereq) == str:
                edges.append((courses.index(prereq), courses.index(course)))
                edge_color.append(
                    "green"
                    if course in completed_courses and prereq in completed_courses
                    else "black"
                )
            elif type(prereq) == list:
                for orreq in prereq:
                    edges.append((courses.index(orreq), courses.index(course)))
                    edge_color.append(
                        "green"
                        if course in completed_courses and orreq in completed_courses
                        else "grey"
                    )

    n_vertices = len(courses)

    tree = ig.Graph(n_vertices, edges)

    tree["title"] = "Skill Tree"
    tree.vs["name"] = ["\n".join(course.split()) for course in courses]
    tree.vs["completed"] = [
        True if course in completed_courses else False for course in courses
    ]

    return tree, edge_color


def tree_to_ImageTk(tree: Tuple[ig.Graph, List[str]]) -> ImageTk:
    tree, edge_color = tree
    fig, ax = plt.subplots(figsize=(6, 5))
    ig.plot(
        tree,
        layout="rt",
        root=0,
        target=ax,
        vertex_size=0.75,
        vertex_color=[
            "green" if completed else "grey" for completed in tree.vs["completed"]
        ],
        vertex_frame_color=[
            "green" if completed else "black" for completed in tree.vs["completed"]
        ],
        vertex_label=tree.vs["name"],
        vertex_label_size=8.0,
        edge_width=2.0,
        edge_color=edge_color,
        edge_arrow_size=2.0,
    )

    fig.savefig("degree_tree.png")
    img = Image.open("degree_tree.png")
    os.remove("degree_tree.png")
    return ImageTk.PhotoImage(img)
